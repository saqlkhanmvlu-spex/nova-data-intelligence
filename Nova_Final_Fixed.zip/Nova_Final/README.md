# Nova — Rebuilt UI

This folder is a ground-up visual redesign of the Nova interface. The previous sidebar / dark studio / top navigation layouts were not reused.

## Design direction
- Editorial / Swiss-inspired layout
- Warm paper background
- Serif display typography + system UI typography
- Thin rules instead of stacked rounded cards
- Large whitespace and strong type hierarchy
- Minimal navigation
- Flat metric strips
- Numbered recommendation rows
- Dark data-matrix visual used only as a supporting visual, not a dashboard shell

## Run
```powershell
python -m venv .venv
.venv\Scripts\activate
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

Open http://localhost:8501

## First test
Use `data/sample_sales.csv`.

## Project idea
UPLOAD → UNDERSTAND → RECOMMEND → ANALYSE → VISUALIZE → PREDICT → INTERPRET


## UX flow

- Import one or more datasets from Overview.
- A successful upload automatically opens the Dataset workspace.
- The current dataset preview appears immediately at the top of the Dataset page.
- Add more files from the Dataset page and use Compare for side-by-side analysis.
- Navigation uses compact workspace buttons rather than a radio-list menu.
